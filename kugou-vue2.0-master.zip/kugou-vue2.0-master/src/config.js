
export default{
	delegateUrl:'https://bird.ioliu.cn/v1/?url=',
	kugouRootPath:"m.kugou.com",
	apiSearch:'http://mobilecdn.kugou.com/api/v3/search/song?format=jsonp&pagesize=30&showtype=1',
	apiSongs:'http://m.kugou.com/app/i/getSongInfo.php?cmd=playInfo',
	apilyrc:'http://cs003.m2828.com/apis/getLrc.php'
}

