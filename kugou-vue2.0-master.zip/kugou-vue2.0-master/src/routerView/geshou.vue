<template>
	<div class="gs-content">
		<ul class="gs-item-list">
			<router-link to="/gsxq/88" tag="li" class="gs-typ-item"><a href="javascript:;"><span>热门歌手</span></a> <i></i></router-link>
		</ul>
		<ul class="gs-item-list">
			<router-link to="/gsxq/1" tag="li" class="gs-typ-item"><a href="javascript:;"><span>华语男歌手</span></a> <i></i></router-link>
			<router-link to="/gsxq/2" tag="li" class="gs-typ-item"><a href="javascript:;"><span>华语女歌手</span></a> <i></i></router-link>
			<router-link to="/gsxq/3" tag="li" class="gs-typ-item"><a href="javascript:;"><span>华语组合</span></a> <i></i></router-link>
		</ul>
		<ul class="gs-item-list">
			<router-link to="/gsxq/4" tag="li" class="gs-typ-item"><a href="javascript:;"><span>日韩男歌手</span></a> <i></i></router-link>
			<router-link to="/gsxq/5" tag="li" class="gs-typ-item"><a href="javascript:;"><span>日韩女歌手</span></a> <i></i></router-link>
			<router-link to="/gsxq/6" tag="li" class="gs-typ-item"><a href="javascript:;"><span>日韩组合</span></a> <i></i></router-link>
		</ul>
		<ul class="gs-item-list">
			<router-link to="/gsxq/7" tag="li" class="gs-typ-item"><a href="javascript:;"><span>欧美男歌手</span></a> <i></i></router-link>
			<router-link to="/gsxq/8" tag="li" class="gs-typ-item"><a href="javascript:;"><span>欧美女歌手</span></a> <i></i></router-link>
			<router-link to="/gsxq/9" tag="li" class="gs-typ-item"><a href="javascript:;"><span>欧美组合</span></a> <i></i></router-link>
		</ul>
	</div>
</template>
