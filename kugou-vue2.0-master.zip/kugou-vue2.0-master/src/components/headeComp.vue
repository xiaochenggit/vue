<template>
	<div class="head-warp">
		<div class="top-fixed">
			<div class="head-comp">
				<a href="#/" class="logo"></a>
				<a href="javascript:;" class="download-app-btn">下载酷狗</a>
				<router-link to="/search">
					<a href="javascript:;" class="search-icon"></a>
				</router-link>	
			</div>
		</div>
		<div class="clear-top-fix">
			<div class="clear-head"></div>
		</div>
	</div>
	
</template>

<script>
	export default {
		
	}
</script>